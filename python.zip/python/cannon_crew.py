class CannonCrew:
    def __init__(self) -> None:
        
